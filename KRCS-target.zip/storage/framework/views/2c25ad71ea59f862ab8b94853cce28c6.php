
<?php $__env->startSection('content'); ?>
 <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Targets</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <br>
    <section class="content">
    <div class="container-fluid">
      <?php echo $__env->make('messages.flash_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card card-danger">
        <div class="card-header">Upload Target</div>
        <form></form>
        <form method="POST" action="<?php echo e(route('target.save')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
        <div class="card-body">
          <div class="row">
            <label>Upload your quater targets</label>
            <input type="file" name="targetF" class="form-control" required>
          </div>
        </div>
        <div class="card-footer">
          <button class="btn btn-danger" class="form-control" type="submit">Upload File</button>
        </div>
      </form>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\KRCS-target\resources\views/pages/target/index.blade.php ENDPATH**/ ?>