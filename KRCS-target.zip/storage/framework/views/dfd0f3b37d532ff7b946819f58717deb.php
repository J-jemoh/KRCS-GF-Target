
<?php $__env->startSection('content'); ?>
 <div class="content-header bg-info">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-white">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.users')); ?>" class="text-white">User Management</a></li>
              <li class="breadcrumb-item active"><a href="#" class="text-white"><?php echo e($user->name); ?></a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <br>
<section class="content">
    <div class="container-fluid">
    	<?php echo $__env->make('messages.flash_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    	<div class="card card-info">
    		<div class="card-header">You are updating user <?php echo e($user->name); ?></div>
    		<div class="card-body">
    			<form></form>
    			<form method="post" action="<?php echo e(route('admin.user.update',$user->id)); ?>">
    				<?php echo csrf_field(); ?>
    				<div class="row">
    					<div class="col-6">
    						<div class="input-group mb-3">
					          <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Full name" name="name" required value="<?php echo e($user->name); ?>">
					          <div class="input-group-append">
					            <div class="input-group-text">
					              <span class="fas fa-user"></span>
					            </div>
					          </div>
					             <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					                                    <span class="invalid-feedback" role="alert">
					                                        <strong><?php echo e($message); ?></strong>
					                                    </span>
					                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					        </div>
    					</div>
    					<div class="col-6">
    						<div class="input-group mb-3">
					          <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email" name="email" required value="<?php echo e($user->email); ?>" autocomplete="email">
					          <div class="input-group-append">
					            <div class="input-group-text">
					              <span class="fas fa-envelope"></span>
					            </div>
					          </div>
					           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					                                    <span class="invalid-feedback" role="alert">
					                                        <strong><?php echo e($message); ?></strong>
					                                    </span>
					                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					        </div>
    					</div>
    					<div class="col-6">   						
					          <div class="input-group mb-3">
					          	<select class="form-control" name="destination" required>
					          		<option><?php echo e($user->destination); ?></option>
					          		<option>M & E Manager</option>
					          		<option>NMO</option>
					          		<option>DMO</option>
					          		<option>RMEO</option>
					          	</select>
					          <div class="input-group-append">
					            <div class="input-group-text">
					              <span class="fas fa-user"></span>
					            </div>
					          </div>
					        </div>
    					</div>
    					<div class="col-6">
    					<div class="input-group mb-3">
				          <select name="region" class="form-control" required>
				          	<option><?php echo e($user->region); ?></option>
				          	<?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				          	<option><?php echo e($region->regionName); ?></option>
				          	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				          </select>
				          <div class="input-group-append">
				            <div class="input-group-text">
				              <span class="fas fa-user"></span>
				            </div>
				          </div>
				        </div>

    					</div>
    					<div class="col-12">
    					<div class="form-group">
                        <label for="roles">Assign Roles</label>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="checkbox">
                            <input name="roles[]" id="checkbox<?php echo e($role->id); ?>" type="checkbox" value="<?php echo e($role->id); ?>"
                                   <?php echo e($user->hasRole($role->name)?'checked="checked"':''); ?>>
                            <label for="checkbox<?php echo e($role->id); ?>">
                                <?php echo e(ucfirst($role->name)); ?>

                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

    					</div>
    					<div class="col-6">	
					        <div class="input-group mb-3">
					          <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password"  autocomplete="new-password">
					          <div class="input-group-append">
					            <div class="input-group-text">
					              <span class="fas fa-lock"></span>
					            </div>
					          </div>
					          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					                                    <span class="invalid-feedback" role="alert">
					                                        <strong><?php echo e($message); ?></strong>
					                                    </span>
					                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					        </div>
    					</div>

    					<div class="col-6">
    						<div class="input-group mb-3">
					          <input type="password" class="form-control" placeholder="Retype password" id="password-confirm" name="password_confirmation" autocomplete="new-password">
					          <div class="input-group-append">
					            <div class="input-group-text">
					              <span class="fas fa-lock"></span>
					            </div>
					          </div>
					        </div>

    					</div>
    					<div class="col-6">
    						   <div class="icheck-primary">
				              <input type="checkbox" id="agreeTerms" name="terms" value="agree">
				              <label for="agreeTerms">
				               I agree to the <a href="#">terms</a>
				              </label>
				            </div>
    					</div>
    					<div class="col-6">
    						<button type="submit" class="btn btn-info float-sm-right">Register</button>
    					</div>
    				</div>
    			</form>
    		</div>
    	</div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\KRCS-target\resources\views/pages/users/updateUser.blade.php ENDPATH**/ ?>