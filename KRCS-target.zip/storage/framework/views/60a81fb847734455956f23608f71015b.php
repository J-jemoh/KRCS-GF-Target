
<?php $__env->startSection('content'); ?>
 <div class="content-header bg-info">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-white">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.gc7')); ?>" class="text-white">Reports</a></li>
              <li class="breadcrumb-item active"><a href="#" class="text-white">GC7-Coverage</a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <br>
  <section class="content">
    <div class="container-fluid">
          <?php echo $__env->make('messages.flash_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="card card-info">
        <div class="card-header">GC7 Program Coverage  </div>
        <div class="card-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Sno</th>
                <th>County</th>
                <th>DHTS</th>
                <th>TCS</th>
                <th>PMTCT</th>
                <th>AYP</th>
                <th>MSM</th>
                <th>FSW</th>
                <th>TG</th>
                <th>PWID</th>
                <th>HRG</th>
                <th>FF</th>
                <th>TRUCKERS</th>
                <th>DC</th>
                <th>PRISON</th>
                <th>Total Program</th>
                <!-- <th>Action</th> -->
              </tr>
            </thead>
            <tbody>
             <?php $__currentLoopData = $coverages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coverage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($coverage->sno); ?></td>
                <td><?php echo e($coverage->county); ?></td>
                <td><span class="badge badge-success"><?php echo e($coverage->dhts); ?></span></td>
                <td><span class="badge badge-info"><?php echo e($coverage->tcs); ?></span></td>
                <td><span class="badge badge-danger"><?php echo e($coverage->pmtct); ?></span></td>
                <td><span class="badge badge-warning"><?php echo e($coverage->ayp); ?></span></td>
                <td><span class="badge badge-secondary"><?php echo e($coverage->msm); ?></span></td>
                <td><span class="badge badge-success"><?php echo e($coverage->fsw); ?></span></td>
                <td><span class="badge badge-info"><?php echo e($coverage->tg); ?></span></td>
                <td><span class="badge badge-danger"><?php echo e($coverage->pwid); ?></span></td>
                <td><span class="badge badge-warning"><?php echo e($coverage->hrg); ?></span></td>
                <td><span class="badge badge-secondary"><?php echo e($coverage->ff); ?></span></td>
                <td><span class="badge badge-success"><?php echo e($coverage->truckers); ?></span></td>
                <td><span class="badge badge-info"><?php echo e($coverage->dc); ?></span></td>
                <td><span class="badge badge-primary"><?php echo e($coverage->prison); ?></span></td>
                <td><span class="badge badge-danger"><?php echo e($coverage->total_program); ?></span></td>
              <!--   <td>
                  <div class="btn-group" role="group" aria-label="Basic example">
                    <button type="button" class="btn btn-info"><i class="fa fa-edit"></i></button>
                    <button type="button" class="btn btn-warning"><i class="fa fa-eye"></i></button>
                    <button type="button" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                  </div>
                </td> -->
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="card-info">
        <div class="card-header">Summary by County for all modules</div>
        <div class="card-body">
          <table id="example2" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>#</th>
                <th>DHTS</th>
                <th>TCS</th>
                <th>PMTCT</th>
                <th>AYP</th>
                <th>MSM</th>
                <th>FSW</th>
                <th>TG</th>
                <th>PWID</th>
                <th>HRG</th>
                <th>FF</th>
                <th>TRUCKERS</th>
                <th>DC</th>
                <th>PRISON</th>
                <th>Total Program</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>No of Counties</td>
                <td><?php echo e($dhts); ?></td>
                <td><?php echo e($tcs); ?></td>
                <td><?php echo e($pmtct); ?></td>
                <td><?php echo e($ayp); ?></td>
                <td><?php echo e($msm); ?></td>
                <td><?php echo e($fsw); ?></td>
                <td><?php echo e($tg); ?></td>
                <td><?php echo e($pwid); ?></td>
                <td><?php echo e($hrg); ?></td>
                <td><?php echo e($ff); ?></td>
                <td><?php echo e($truckers); ?></td>
                <td><?php echo e($dc); ?></td>
                <td><?php echo e($prison); ?></td>
                <td><?php echo e($total); ?></td>

              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <br>
      <div class="card card-info">
        <div class="card-header">Visualization of modules</div>
        <div class="card-body">
          <canvas id="moduleChart" width="500" class="bg-light" height="130"></canvas>
        </div>
      </div>
    </div>
  </section>

  <?php $__env->stopSection(); ?>
   <script>
        document.addEventListener("DOMContentLoaded", function() {
            var ctx = document.getElementById('moduleChart').getContext('2d');

            var modules = <?php echo json_encode($modules); ?>;
            var moduleLabels = Object.keys(modules);
            var moduleCounts = Object.values(modules);

            var colors = generateRandomColors(moduleLabels.length);

            var myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: moduleLabels,
                    datasets: [{
                        label: 'Module Counts',
                        data: moduleCounts,
                        backgroundColor: colors,
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }
                }
            });

            function generateRandomColors(count) {
                var colors = [];
                for (var i = 0; i < count; i++) {
                    colors.push('rgba(' + Math.floor(Math.random() * 200 + 55) + ',' + Math.floor(Math.random() * 200 + 55) + ',' + Math.floor(Math.random() * 200 + 55) + ',0.6)');
                }
                return colors;
            }
        });
    </script>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\KRCS-target\resources\views/pages/gc7/coverage.blade.php ENDPATH**/ ?>