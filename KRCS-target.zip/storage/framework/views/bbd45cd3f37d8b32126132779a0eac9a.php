
<?php $__env->startSection('content'); ?>
 <div class="content-header bg-info">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-white">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.target.all')); ?>" class="text-white">Targets</a></li>
               <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.target.reports')); ?>" class="text-white">Reports</a></li>
                <li class="breadcrumb-item active text-white">FSW</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <br>
     <section class="content">
    <div class="container-fluid">
    	    	<div class="row">
     
      	 <div class="col-12 col-sm-6 col-md-4">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cog"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">No. of Regions</span>
                <span class="info-box-number">
                  <?php echo e($regions); ?>

                  <small></small>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
           	<div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-4">
              <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-bars"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">No. of SRS</span>
                <span class="info-box-number"><?php echo e($sr); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <div class="col-12 col-sm-6 col-md-4">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-bars"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">No of Counties</span>
                <span class="info-box-number"><?php echo e($counties); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
      </div>
    	<div class="card card-info">
    		<div class="card-header"><b>FSW TARGET INDICATOR</b></div>
    		<div class="card-body">
    			<table id="example1" class="table table-bordered table-striped">
    				<thead>
    					<tr>
    						<th>SNo</th>
    						<th>Module</th>
    						<th>Quater</th>
    						<th>Year</th>
    						<th>Region</th>
    						<th>SR</th>
    						<th>County</th>
    						<th>Defined(Q1)</th>
    						<th>Defined (Q2)</th>
    						<th>Defined(Target)</th>
    						<th>Defined(Sem)</th>
    						<th>Defined(Performance)</th>
    						<th>HTS(Q1)</th>
    						<th>HTS(Q2)</th>
    						<th>HTS(Target)</th>
    						<th>HTS(Sem)</th>
    						<th>HTS(Performance)</th>
    						<th>Prep(Q1)</th>
    						<th>Prep(Q2)</th>
    						<th>Prep(Target)</th>
    						<th>Prep(Total)</th>
    						<th>Prep(Performance)</th>
    					</tr>
    				</thead>
    				<tbody>
    					<?php $__currentLoopData = $fswdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    					<tr>
			    		  <td><?php echo e($target->sno); ?></td>
			              <td><?php echo e($target->module); ?></td>
			              <td><?php echo e($target->quater); ?></td>
			              <td><?php echo e($target->year); ?></td>
			              <td><?php echo e($target->reqion); ?></td>
			              <td><?php echo e($target->sr); ?></td>
			              <td><?php echo e($target->county); ?></td>
			              <td><?php echo e($target->defined_q1); ?></td>
			              <td><?php echo e($target->defined_q2); ?></td>
			              <td><?php echo e($target->defined_target); ?></td>
			              <td><?php echo e($target->defined_sem); ?></td>
			              <td><?php echo e($target->defined_performance); ?></td>
			              <td><?php echo e($target->hts_q1); ?></td>
			              <td><?php echo e($target->hts_q2); ?></td>
			              <td><?php echo e($target->hts_target); ?></td>
			              <td><?php echo e($target->hts_sem); ?></td>
			              <td><?php echo e($target->hts_performance); ?></td>
			              <td><?php echo e($target->prep_q1); ?></td>
			              <td><?php echo e($target->prep_q2); ?></td>
			              <td><?php echo e($target->prep_target); ?></td>
			              <td><?php echo e($target->prep_total); ?></td>
			              <td><?php echo e($target->prep_performance); ?></td>
    					</tr>
    					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    				</tbody>
    			</table>
    		</div>
    	</div>
    </div>
          <div class="container-fluid">
          <div class="row">
            <div class="col-lg-8">
              <div class="card card-info">
            <div class="card-header"><b>Performance Visualizations by County</b></div>
            <div class="card-body">
              <div style="width: 100%;">
                <canvas id="myChartmsmCounty"></canvas>
            </div>
            </div>
          </div>
            </div>
              <div class="col-lg-4">
              <div class="card card-info">
            <div class="card-header"><b>Performance Visualizations by Region</b></div>
            <div class="card-body">
              <div style="width: 100%;">
                <canvas id="myChartmsm"></canvas>
            </div>
            </div>
          </div>
            </div>
          </div>
          
        </div>
</section>
 <?php $__env->stopSection(); ?>
 <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Extracting data from PHP to JavaScript
            var data = <?php echo json_encode($barFSW, 15, 512) ?>;

            // Processing data for Chart.js
            var chartData = {};
            data.forEach(function(item) {
                if (!chartData[item.reqion]) {
                    chartData[item.reqion] = {};
                }
                chartData[item.reqion][item.module] = item.avg_performance;
            });

            // Creating dataset for Chart.js
            var datasets = [];
            for (var region in chartData) {
                var moduleData = chartData[region];
                var dataset = {
                    label: region,
                    data: Object.values(moduleData),
                    backgroundColor: 'rgba(' + Math.floor(Math.random() * 255) + ',' + Math.floor(Math.random() * 255) + ',' + Math.floor(Math.random() * 255) + ',0.6)',
                };
                datasets.push(dataset);
            }

            // Drawing chart with Chart.js
            var ctx = document.getElementById('myChartmsm');
            if (ctx) {
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: Object.keys(chartData[Object.keys(chartData)[0]]),
                        datasets: datasets
                    },
                    options: {
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    }
                });
            } else {
                console.error("Canvas element with ID 'myChart' not found.");
            }
        });
    </script>
    <!-- group by county -->
       <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Extracting data from PHP to JavaScript
            var data = <?php echo json_encode($barFSWCounty, 15, 512) ?>;

            // Processing data for Chart.js
            var chartData = {};
            data.forEach(function(item) {
                if (!chartData[item.county]) {
                    chartData[item.county] = {};
                }
                chartData[item.county][item.module] = item.avg_performance;
            });

            // Creating dataset for Chart.js
            var datasets = [];
            for (var county in chartData) {
                var moduleData = chartData[county];
                var dataset = {
                    label: county,
                    data: Object.values(moduleData),
                    backgroundColor: 'rgba(' + Math.floor(Math.random() * 255) + ',' + Math.floor(Math.random() * 255) + ',' + Math.floor(Math.random() * 255) + ',0.6)',
                };
                datasets.push(dataset);
            }

            // Drawing chart with Chart.js
            var ctx = document.getElementById('myChartmsmCounty');
            if (ctx) {
                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: Object.keys(chartData[Object.keys(chartData)[0]]),
                        datasets: datasets
                    },
                    options: {
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero: true
                                }
                            }]
                        }
                    }
                });
            } else {
                console.error("Canvas element with ID 'myChart' not found.");
            }
        });
    </script>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\KRCS-target\resources\views/pages/target/fsw.blade.php ENDPATH**/ ?>