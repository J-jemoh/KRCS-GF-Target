
<?php $__env->startSection('content'); ?>
 <div class="content-header bg-info">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-white">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.gc7')); ?>" class="text-white">User Management</a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <br>
  <section class="content">
  	<?php echo $__env->make('messages.flash_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid">
    	<div class="card card-info">
    		<div class="card-header"><b>All Users</b>
    			<a href="<?php echo e(route('admin.users.new')); ?>" class="btn btn-danger float-sm-right">Add  New User</a>
    		</div>
    		<div class="card-body">
    			 <table id="example1" class="table table-bordered table-striped">
    			 	<thead>
    			 		<tr>
    			 			<th>#</th>
    			 			<th>Name</th>
    			 			<th>Email</th>
    			 			<th>Designation</th>
    			 			<th>Region</th>
    			 			<th>Action</th>
    			 		</tr>
    			 	</thead>
    			 	<tbody>
    			 		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			 		<tr>
    			 			<td><?php echo e($user->id); ?></td>
    			 			<td><?php echo e($user->name); ?></td>
    			 			<td><?php echo e($user->email); ?></td>
    			 			<td><span class="badge badge-info"><?php echo e($user->destination); ?></span></td>
    			 			<td><?php echo e($user->region); ?></td>
    			 			<td>
    			 				<div class="btn-group" role="group" aria-label="Basic example">
				                    <a type="button" class="btn btn-info" href="<?php echo e(route('admin.user.edit',$user->id)); ?>"><i class="fa fa-edit"></i></a>
				                    <a type="button" class="btn btn-warning" href="#"><i class="fa fa-eye"></i></a>
				                    <a type="button" href="#" class="btn btn-danger"><i class="fa fa-trash"></i></a>
				                  </div>
    			 			</td>
    			 		</tr>
    			 		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			 	</tbody>
    			 </table>
    		</div>
    	</div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\KRCS-target\resources\views/pages/users/index.blade.php ENDPATH**/ ?>