    <div class="row mb-3">
      <div class="col-12 col-sm-4 col-lg-6 mb-2">
        User Live Search <small>(use the search button before selecting the dropdown to search for a specific user)</small>
      </div>
      <div class="col-12 col-sm-4 col-lg-2 mb-2">
        <input type="text" id='live_search_email' name='live_search_email' placeholder='Email'>
      </div>
      <div class="col-12 col-sm-4 col-lg-2 mb-2">
        <input type="text" id='live_search_userid' name='live_search_userid' placeholder='UserId'>
      </div>
      <div class="col-12 col-sm-4 col-lg-2 mb-2">
        <input id="live_search_button" class="btn btn-primary btn-block" value="<?php echo e(trans('LaravelLogger::laravel-logger.dashboard.search.search')); ?>">
      </div>
    </div>
<?php /**PATH C:\Apache24\htdocs\KRCS-target\resources\views/vendor/LaravelLogger/partials/form-live-search.blade.php ENDPATH**/ ?>