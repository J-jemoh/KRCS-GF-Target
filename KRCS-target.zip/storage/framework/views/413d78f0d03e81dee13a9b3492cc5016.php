<script type="text/javascript">
    $(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script><?php /**PATH C:\Apache24\htdocs\KRCS-target\resources\views/vendor/LaravelLogger/scripts/tooltip.blade.php ENDPATH**/ ?>